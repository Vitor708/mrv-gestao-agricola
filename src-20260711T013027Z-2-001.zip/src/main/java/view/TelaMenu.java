
package view;

import javax.swing.JOptionPane;
import model.Usuario;


public class TelaMenu extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(TelaMenu.class.getName());
   private model.Usuario usuarioLogado;
   
   public TelaMenu() {
    this(null);
    
}
      public TelaMenu(Usuario usuario) {
      initComponents();
      this.usuarioLogado = usuario;
      setLocationRelativeTo(null);
      configurarTela();
      carregarDados();
      carregarIcones();
      aplicarHoverBotoes();
      aplicarHoverCards();
}
private void configurarTela() {
    String nome = (usuarioLogado != null) ? usuarioLogado.getNome() : "Usuário";
    lblUsuario.setText(nome);
    lblBoasVindas.setText("Bem-vindo, " + nome + "!");

    java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat(
        "dd 'de' MMMM, yyyy", new java.util.Locale("pt", "BR"));
    String hoje = sdf.format(new java.util.Date());
    lblData.setText(hoje);
    if (lblData1 != null) lblData1.setText(hoje);
}

 private void carregarDados() {
    int idUsuario = (usuarioLogado != null) ? usuarioLogado.getId() : 0;
    try {
        int fazendas  = new dao.FazendaDAO().contarPorUsuario(idUsuario);
        int plantios  = new dao.PlantioDAO().contarPorUsuario(idUsuario);
        int animais   = new dao.AnimaisDAO().contarPorUsuario(idUsuario);
        int colheitas = new dao.ColheitaDAO().contarPorUsuario(idUsuario);

        lblTxtFazendas.setText("Fazendas");
        lblSubFazendas.setText("Total cadastradas");
        lblTxtplantacoes.setText("Plantações");
        lblSubplantacoes.setText("Em andamento");
        lblTxtanimais.setText("Animais");
        lblSubanimais.setText("Total ativos");
        lblTxtcolheitas.setText("Colheitas");
        lblSubcolheitas.setText("Realizadas");

        javax.swing.SwingUtilities.invokeLater(() -> {
            animarContador(lblNumFazendas,  fazendas);

            new javax.swing.Timer(200, e -> {
                animarContador(lblNumplantacoes, plantios);
                ((javax.swing.Timer) e.getSource()).stop();
            }).start();

            new javax.swing.Timer(400, e -> {
                animarContador(lblNumanimais, animais);
                ((javax.swing.Timer) e.getSource()).stop();
            }).start();

            new javax.swing.Timer(600, e -> {
                animarContador(lblNumcolheitas, colheitas);
                ((javax.swing.Timer) e.getSource()).stop();
            }).start();
        });

    } catch (Exception e) {
        logger.log(java.util.logging.Level.SEVERE, "Erro ao carregar dados", e);
    }

}
    private void carregarIcones() {
    setIconeLabel(jLabel7, "/img/fazenda.png");
    setIconeLabel(jLabel4, "/img/plantio.png");
    setIconeLabel(jLabel5, "/img/animais.png");
    setIconeLabel(jLabel8, "/img/colheita.png");
}
    private void aplicarHoverCards() {
    javax.swing.JPanel[] cards = {
        cardFazendas, cardPlantacoes, cardAnimais, cardColheitas
    };
    

    java.awt.Color corNormal = new java.awt.Color(15, 50, 20);
    java.awt.Color corHover  = new java.awt.Color(25, 75, 30);

    for (javax.swing.JPanel card : cards) {
        card.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseEntered(java.awt.event.MouseEvent e) {
                card.setBackground(corHover);
                for (java.awt.Component comp : card.getComponents()) {
                    comp.setBackground(corHover);
                }
            }

            @Override
            public void mouseExited(java.awt.event.MouseEvent e) {
                card.setBackground(corNormal);
                for (java.awt.Component comp : card.getComponents()) {
                    comp.setBackground(corNormal);
                }
            }
        });
    }
}
   
    private void animarContador(javax.swing.JLabel label, int valorFinal) {
    int duracao = 1000; // milissegundos
    int passos = 30;
    int delay = duracao / passos;

    javax.swing.Timer timer = new javax.swing.Timer(delay, null);
    final int[] atual = {0};

    timer.addActionListener(e -> {
        atual[0]++;
        int valorAtual = (int) Math.round((valorFinal * atual[0]) / (double) passos);
        label.setText(String.valueOf(valorAtual));

        if (atual[0] >= passos) {
            label.setText(String.valueOf(valorFinal));
            ((javax.swing.Timer) e.getSource()).stop();
        }
    });

    timer.start();
}
    private void aplicarHoverBotoes() {
    javax.swing.JButton[] botoes = {
        btnFazenda, btnCultura, btnPlantacoes, btnAnimais,
        btnEstoque, btnColheitas, btnSobre, btnVoltar, btnSair
    };

    java.awt.Color corNormal = new java.awt.Color(15, 50, 20);
    java.awt.Color corHover  = new java.awt.Color(30, 90, 35);
    java.awt.Color corTexto  = new java.awt.Color(255, 255, 255);
    java.awt.Color corTextoHover = new java.awt.Color(100, 220, 100);

    for (javax.swing.JButton btn : botoes) {
        btn.setOpaque(true);
        btn.setContentAreaFilled(true);
        btn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseEntered(java.awt.event.MouseEvent e) {
                btn.setBackground(corHover);
                btn.setForeground(corTextoHover);
            }

            @Override
            public void mouseExited(java.awt.event.MouseEvent e) {
                btn.setBackground(corNormal);
                btn.setForeground(corTexto);
            }
        });
    }
}
    private void setIconeLabel(javax.swing.JLabel label, String caminho) {
    try {
        java.net.URL url = getClass().getResource(caminho);
        if (url == null) {
            logger.log(java.util.logging.Level.WARNING, "Icone nao encontrado: " + caminho);
            return;
        }
        java.awt.Image img = new javax.swing.ImageIcon(url).getImage();
        java.awt.Image imgEscalada = img.getScaledInstance(80, 80, java.awt.Image.SCALE_SMOOTH);
        label.setIcon(new javax.swing.ImageIcon(imgEscalada));
        label.setText(null);
        label.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        label.setVerticalAlignment(javax.swing.SwingConstants.CENTER);
    } catch (Exception e) {
        logger.log(java.util.logging.Level.SEVERE, "Erro ao carregar icone: " + caminho, e);
    }
    
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jYearChooser1 = new com.toedter.calendar.JYearChooser();
        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        lblData = new javax.swing.JLabel();
        lblBoasVindas = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        lblUsuario = new javax.swing.JLabel();
        lblData1 = new javax.swing.JLabel();
        cardFazendas = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        lblNumFazendas = new javax.swing.JLabel();
        lblTxtFazendas = new javax.swing.JLabel();
        lblSubFazendas = new javax.swing.JLabel();
        cardPlantacoes = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        lblTxtplantacoes = new javax.swing.JLabel();
        lblNumplantacoes = new javax.swing.JLabel();
        lblSubplantacoes = new javax.swing.JLabel();
        cardAnimais = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        lblTxtanimais = new javax.swing.JLabel();
        lblNumanimais = new javax.swing.JLabel();
        lblSubanimais = new javax.swing.JLabel();
        cardColheitas = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        lblTxtcolheitas = new javax.swing.JLabel();
        lblNumcolheitas = new javax.swing.JLabel();
        lblSubcolheitas = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        btnFazenda = new javax.swing.JButton();
        btnCultura = new javax.swing.JButton();
        btnPlantacoes = new javax.swing.JButton();
        btnAnimais = new javax.swing.JButton();
        btnEstoque = new javax.swing.JButton();
        btnColheitas = new javax.swing.JButton();
        btnSobre = new javax.swing.JButton();
        btnSair = new javax.swing.JButton();
        btnVoltar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(15, 50, 20));

        jPanel3.setBackground(new java.awt.Color(15, 50, 20));
        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(100, 220, 100), 3));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(100, 220, 100));
        jLabel3.setText("Dashboard");

        lblData.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblData.setForeground(new java.awt.Color(255, 255, 255));
        lblData.setText("Data");

        lblBoasVindas.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblBoasVindas.setForeground(new java.awt.Color(255, 255, 255));
        lblBoasVindas.setText("Usuario");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addComponent(lblData))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblBoasVindas)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblData))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addComponent(lblBoasVindas)))
                .addContainerGap(22, Short.MAX_VALUE))
        );

        jPanel5.setBackground(new java.awt.Color(15, 50, 20));
        jPanel5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(100, 220, 100), 3));

        lblUsuario.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblUsuario.setForeground(new java.awt.Color(100, 220, 100));
        lblUsuario.setText("Bem-Vindo, Usuario");

        lblData1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblData1.setForeground(new java.awt.Color(255, 255, 255));
        lblData1.setText("Aqui está o resumo geral da sua prioridade hoje.");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblUsuario)
                    .addComponent(lblData1))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblUsuario)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblData1)
                .addContainerGap(17, Short.MAX_VALUE))
        );

        cardFazendas.setBackground(new java.awt.Color(15, 50, 20));
        cardFazendas.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(100, 220, 100), 2));

        jLabel7.setPreferredSize(new java.awt.Dimension(80, 80));

        lblNumFazendas.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        lblNumFazendas.setForeground(new java.awt.Color(100, 220, 100));
        lblNumFazendas.setText("10");

        lblTxtFazendas.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblTxtFazendas.setForeground(new java.awt.Color(100, 220, 100));
        lblTxtFazendas.setText("Fazendas");

        lblSubFazendas.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblSubFazendas.setForeground(new java.awt.Color(255, 255, 255));
        lblSubFazendas.setText("Total Cadastradas");

        javax.swing.GroupLayout cardFazendasLayout = new javax.swing.GroupLayout(cardFazendas);
        cardFazendas.setLayout(cardFazendasLayout);
        cardFazendasLayout.setHorizontalGroup(
            cardFazendasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardFazendasLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(cardFazendasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(cardFazendasLayout.createSequentialGroup()
                        .addComponent(lblTxtFazendas)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(cardFazendasLayout.createSequentialGroup()
                        .addComponent(lblNumFazendas)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 32, Short.MAX_VALUE)
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(17, 17, 17))
                    .addGroup(cardFazendasLayout.createSequentialGroup()
                        .addComponent(lblSubFazendas)
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        cardFazendasLayout.setVerticalGroup(
            cardFazendasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, cardFazendasLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblTxtFazendas)
                .addGap(18, 18, 18)
                .addGroup(cardFazendasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblNumFazendas))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblSubFazendas)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        cardPlantacoes.setBackground(new java.awt.Color(15, 50, 20));
        cardPlantacoes.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 153, 0), 2));

        jLabel4.setPreferredSize(new java.awt.Dimension(80, 80));

        lblTxtplantacoes.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblTxtplantacoes.setForeground(new java.awt.Color(204, 153, 0));
        lblTxtplantacoes.setText("Plantações");

        lblNumplantacoes.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        lblNumplantacoes.setForeground(new java.awt.Color(204, 153, 0));
        lblNumplantacoes.setText("10");

        lblSubplantacoes.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblSubplantacoes.setForeground(new java.awt.Color(255, 255, 255));
        lblSubplantacoes.setText("Em andamento");

        javax.swing.GroupLayout cardPlantacoesLayout = new javax.swing.GroupLayout(cardPlantacoes);
        cardPlantacoes.setLayout(cardPlantacoesLayout);
        cardPlantacoesLayout.setHorizontalGroup(
            cardPlantacoesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardPlantacoesLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(cardPlantacoesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(cardPlantacoesLayout.createSequentialGroup()
                        .addComponent(lblTxtplantacoes)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(cardPlantacoesLayout.createSequentialGroup()
                        .addComponent(lblNumplantacoes)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 33, Short.MAX_VALUE)
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(23, 23, 23))
                    .addGroup(cardPlantacoesLayout.createSequentialGroup()
                        .addComponent(lblSubplantacoes)
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        cardPlantacoesLayout.setVerticalGroup(
            cardPlantacoesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, cardPlantacoesLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblTxtplantacoes)
                .addGap(18, 18, 18)
                .addGroup(cardPlantacoesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblNumplantacoes))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblSubplantacoes)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        cardAnimais.setBackground(new java.awt.Color(15, 50, 20));
        cardAnimais.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 153, 153), 2));

        jLabel5.setPreferredSize(new java.awt.Dimension(80, 80));

        lblTxtanimais.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblTxtanimais.setForeground(new java.awt.Color(0, 153, 153));
        lblTxtanimais.setText("Animais");

        lblNumanimais.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        lblNumanimais.setForeground(new java.awt.Color(0, 153, 153));
        lblNumanimais.setText("10");

        lblSubanimais.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblSubanimais.setForeground(new java.awt.Color(255, 255, 255));
        lblSubanimais.setText("Total ativos");

        javax.swing.GroupLayout cardAnimaisLayout = new javax.swing.GroupLayout(cardAnimais);
        cardAnimais.setLayout(cardAnimaisLayout);
        cardAnimaisLayout.setHorizontalGroup(
            cardAnimaisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardAnimaisLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(cardAnimaisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(cardAnimaisLayout.createSequentialGroup()
                        .addComponent(lblSubanimais)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(cardAnimaisLayout.createSequentialGroup()
                        .addGroup(cardAnimaisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblNumanimais)
                            .addComponent(lblTxtanimais))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(30, 30, 30))))
        );
        cardAnimaisLayout.setVerticalGroup(
            cardAnimaisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardAnimaisLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblTxtanimais)
                .addGap(18, 18, 18)
                .addGroup(cardAnimaisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblNumanimais)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 10, Short.MAX_VALUE)
                .addComponent(lblSubanimais)
                .addGap(22, 22, 22))
        );

        cardColheitas.setBackground(new java.awt.Color(15, 50, 20));
        cardColheitas.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 0, 153), 2));

        jLabel8.setPreferredSize(new java.awt.Dimension(80, 80));

        lblTxtcolheitas.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblTxtcolheitas.setForeground(new java.awt.Color(153, 0, 153));
        lblTxtcolheitas.setText("Colheitas");

        lblNumcolheitas.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        lblNumcolheitas.setForeground(new java.awt.Color(153, 0, 153));
        lblNumcolheitas.setText("10");

        lblSubcolheitas.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblSubcolheitas.setForeground(new java.awt.Color(255, 255, 255));
        lblSubcolheitas.setText(" Realizadas");

        javax.swing.GroupLayout cardColheitasLayout = new javax.swing.GroupLayout(cardColheitas);
        cardColheitas.setLayout(cardColheitasLayout);
        cardColheitasLayout.setHorizontalGroup(
            cardColheitasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardColheitasLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(cardColheitasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(cardColheitasLayout.createSequentialGroup()
                        .addComponent(lblSubcolheitas)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(cardColheitasLayout.createSequentialGroup()
                        .addGroup(cardColheitasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblTxtcolheitas)
                            .addComponent(lblNumcolheitas))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18))))
        );
        cardColheitasLayout.setVerticalGroup(
            cardColheitasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardColheitasLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblTxtcolheitas)
                .addGap(18, 18, 18)
                .addGroup(cardColheitasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblNumcolheitas)
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblSubcolheitas)
                .addGap(21, 21, 21))
        );

        jPanel10.setBackground(new java.awt.Color(15, 50, 20));
        jPanel10.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(100, 220, 100), 3));

        jPanel2.setBackground(new java.awt.Color(15, 50, 20));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(100, 220, 100));
        jLabel1.setText("BioTech");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(100, 220, 100));
        jLabel2.setText("Sistema Agricola");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(jLabel1))
                .addGap(0, 18, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addContainerGap(31, Short.MAX_VALUE))
        );

        btnFazenda.setBackground(new java.awt.Color(15, 50, 20));
        btnFazenda.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnFazenda.setForeground(new java.awt.Color(255, 255, 255));
        btnFazenda.setText("Fazendas");
        btnFazenda.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(15, 50, 20)));
        btnFazenda.addActionListener(this::btnFazendaActionPerformed);

        btnCultura.setBackground(new java.awt.Color(15, 50, 20));
        btnCultura.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnCultura.setForeground(new java.awt.Color(255, 255, 255));
        btnCultura.setText("Cultura");
        btnCultura.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(15, 50, 20)));
        btnCultura.addActionListener(this::btnCulturaActionPerformed);

        btnPlantacoes.setBackground(new java.awt.Color(15, 50, 20));
        btnPlantacoes.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnPlantacoes.setForeground(new java.awt.Color(255, 255, 255));
        btnPlantacoes.setText("Plantações");
        btnPlantacoes.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(15, 50, 20)));
        btnPlantacoes.addActionListener(this::btnPlantacoesActionPerformed);

        btnAnimais.setBackground(new java.awt.Color(15, 50, 20));
        btnAnimais.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnAnimais.setForeground(new java.awt.Color(255, 255, 255));
        btnAnimais.setText("Animais");
        btnAnimais.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(15, 50, 20)));
        btnAnimais.addActionListener(this::btnAnimaisActionPerformed);

        btnEstoque.setBackground(new java.awt.Color(15, 50, 20));
        btnEstoque.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnEstoque.setForeground(new java.awt.Color(255, 255, 255));
        btnEstoque.setText("Estoque");
        btnEstoque.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(15, 50, 20)));
        btnEstoque.addActionListener(this::btnEstoqueActionPerformed);

        btnColheitas.setBackground(new java.awt.Color(15, 50, 20));
        btnColheitas.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnColheitas.setForeground(new java.awt.Color(255, 255, 255));
        btnColheitas.setText("Colheitas");
        btnColheitas.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(15, 50, 20)));
        btnColheitas.addActionListener(this::btnColheitasActionPerformed);

        btnSobre.setBackground(new java.awt.Color(15, 50, 20));
        btnSobre.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnSobre.setForeground(new java.awt.Color(255, 255, 255));
        btnSobre.setText("Sobre");
        btnSobre.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(15, 50, 20)));
        btnSobre.addActionListener(this::btnSobreActionPerformed);

        btnSair.setBackground(new java.awt.Color(15, 50, 20));
        btnSair.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnSair.setForeground(new java.awt.Color(255, 255, 255));
        btnSair.setText("Sair");
        btnSair.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(15, 50, 20)));
        btnSair.addActionListener(this::btnSairActionPerformed);

        btnVoltar.setBackground(new java.awt.Color(15, 50, 20));
        btnVoltar.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnVoltar.setForeground(new java.awt.Color(255, 255, 255));
        btnVoltar.setText("Voltar");
        btnVoltar.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(15, 50, 20)));
        btnVoltar.addActionListener(this::btnVoltarActionPerformed);

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(btnFazenda, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(btnCultura, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(btnAnimais, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(btnEstoque, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(btnColheitas, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnSair, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnSobre, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnVoltar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnPlantacoes, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(49, 49, 49)
                .addComponent(btnFazenda)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnCultura)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnEstoque)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnPlantacoes)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnAnimais)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnColheitas)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 94, Short.MAX_VALUE)
                .addComponent(btnSobre)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnVoltar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnSair))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(36, 36, 36)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jPanel5, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(cardFazendas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(cardPlantacoes, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(cardAnimais, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(cardColheitas, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(43, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(cardColheitas, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cardAnimais, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cardPlantacoes, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cardFazendas, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnFazendaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFazendaActionPerformed
    new TelaRegistrarFazenda(usuarioLogado).setVisible(true);
    this.dispose();
    }//GEN-LAST:event_btnFazendaActionPerformed

    private void btnCulturaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCulturaActionPerformed
    new CadCulturs(usuarioLogado).setVisible(true);
    this.dispose();
    }//GEN-LAST:event_btnCulturaActionPerformed

    private void btnPlantacoesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPlantacoesActionPerformed
    new CadPlantio(usuarioLogado).setVisible(true);
    this.dispose();
    }//GEN-LAST:event_btnPlantacoesActionPerformed

    private void btnAnimaisActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAnimaisActionPerformed
    new CadAnimais(usuarioLogado).setVisible(true);
    this.dispose();
    }//GEN-LAST:event_btnAnimaisActionPerformed

    private void btnEstoqueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEstoqueActionPerformed
    new CadEstoque(usuarioLogado).setVisible(true);
    this.dispose();
    }//GEN-LAST:event_btnEstoqueActionPerformed

    private void btnColheitasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnColheitasActionPerformed
    new CadColheita(usuarioLogado).setVisible(true);
    this.dispose();
    }//GEN-LAST:event_btnColheitasActionPerformed

    private void btnSobreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSobreActionPerformed
    new TelaSobre(usuarioLogado).setVisible(true);
    this.dispose();
    }//GEN-LAST:event_btnSobreActionPerformed

    private void btnSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSairActionPerformed
    int opcao = JOptionPane.showConfirmDialog(
    null,
    "Tem certeza que deseja sair?",
    "Sair do sistema",
    JOptionPane.YES_NO_OPTION,
    JOptionPane.QUESTION_MESSAGE
    );

    if (opcao == JOptionPane.YES_OPTION) {
    System.exit(0);
}
   
    }//GEN-LAST:event_btnSairActionPerformed

    private void btnVoltarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVoltarActionPerformed
    int opcao = JOptionPane.showConfirmDialog(
    null,
    "Tem certeza que deseja Voltar para o Login?",
    "Sair do sistema",
    JOptionPane.YES_NO_OPTION,
    JOptionPane.QUESTION_MESSAGE
    );
    if (opcao == JOptionPane.YES_OPTION) {
    new TelaLogin().setVisible(true);
    this.dispose();
}  
    }//GEN-LAST:event_btnVoltarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new TelaMenu().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAnimais;
    private javax.swing.JButton btnColheitas;
    private javax.swing.JButton btnCultura;
    private javax.swing.JButton btnEstoque;
    private javax.swing.JButton btnFazenda;
    private javax.swing.JButton btnPlantacoes;
    private javax.swing.JButton btnSair;
    private javax.swing.JButton btnSobre;
    private javax.swing.JButton btnVoltar;
    private javax.swing.JPanel cardAnimais;
    private javax.swing.JPanel cardColheitas;
    private javax.swing.JPanel cardFazendas;
    private javax.swing.JPanel cardPlantacoes;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel5;
    private com.toedter.calendar.JYearChooser jYearChooser1;
    private javax.swing.JLabel lblBoasVindas;
    private javax.swing.JLabel lblData;
    private javax.swing.JLabel lblData1;
    private javax.swing.JLabel lblNumFazendas;
    private javax.swing.JLabel lblNumanimais;
    private javax.swing.JLabel lblNumcolheitas;
    private javax.swing.JLabel lblNumplantacoes;
    private javax.swing.JLabel lblSubFazendas;
    private javax.swing.JLabel lblSubanimais;
    private javax.swing.JLabel lblSubcolheitas;
    private javax.swing.JLabel lblSubplantacoes;
    private javax.swing.JLabel lblTxtFazendas;
    private javax.swing.JLabel lblTxtanimais;
    private javax.swing.JLabel lblTxtcolheitas;
    private javax.swing.JLabel lblTxtplantacoes;
    private javax.swing.JLabel lblUsuario;
    // End of variables declaration//GEN-END:variables
}
