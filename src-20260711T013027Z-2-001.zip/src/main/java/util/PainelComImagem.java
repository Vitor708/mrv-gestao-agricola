package util;

import java.awt.Graphics;
import java.awt.Image;
import javax.swing.JPanel;

public class PainelComImagem extends JPanel {

    private Image imagem;

    public PainelComImagem(String caminho) {
        try {
            java.io.File arquivo = new java.io.File(caminho);
            if (arquivo.exists()) {
                imagem = javax.imageio.ImageIO.read(arquivo);
            }
        } catch (Exception e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (imagem != null) {
            g.drawImage(imagem, 0, 0, getWidth(), getHeight(), this);
        }
    }
}