package util;

import java.util.Hashtable;
import javax.naming.Context;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.InitialDirContext;

public class Validador {

    public static boolean validarFormatoEmail(String email) {
        if (email == null || email.trim().isEmpty()) return false;
        String regex = "^[\\w.+-]+@[\\w-]+\\.[a-zA-Z]{2,}$";
        return email.trim().matches(regex);
    }

    // Verifica se o domínio do e-mail existe de fato (tem servidor de e-mail configurado)
    public static boolean dominioEmailExiste(String email) {
        try {
            String dominio = email.substring(email.indexOf("@") + 1);
            Hashtable<String, String> env = new Hashtable<>();
            env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.dns.DnsContextFactory");
            InitialDirContext dirContext = new InitialDirContext(env);
            Attributes attrs = dirContext.getAttributes(dominio, new String[]{"MX"});
            Attribute mx = attrs.get("MX");
            return mx != null && mx.size() > 0;
        } catch (Exception e) {
            return false;
        }
    }

    public static boolean validarCPF(String cpf) {
        if (cpf == null) return false;
        cpf = cpf.replaceAll("[^0-9]", "");

        if (cpf.length() != 11) return false;
        if (cpf.matches("(\\d)\\1{10}")) return false;

        int[] digitos = new int[11];
        for (int i = 0; i < 11; i++) {
            digitos[i] = Character.getNumericValue(cpf.charAt(i));
        }

        int soma = 0;
        for (int i = 0; i < 9; i++) soma += digitos[i] * (10 - i);
        int resto = soma % 11;
        int dv1 = (resto < 2) ? 0 : 11 - resto;
        if (dv1 != digitos[9]) return false;

        soma = 0;
        for (int i = 0; i < 10; i++) soma += digitos[i] * (11 - i);
        resto = soma % 11;
        int dv2 = (resto < 2) ? 0 : 11 - resto;
        return dv2 == digitos[10];
    }
}