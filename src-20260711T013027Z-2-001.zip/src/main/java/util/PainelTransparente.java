package util;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.JPanel;

public class PainelTransparente extends JPanel {

    public PainelTransparente() {
        setOpaque(false);
    }

    @Override
    protected void paintComponent(Graphics g) {

        Graphics2D g2 = (Graphics2D) g.create();

        g2.setColor(new Color(0, 0, 0, 180));

        g2.fillRoundRect(
                0,
                0,
                getWidth(),
                getHeight(),
                40,
                40
        );

        g2.dispose();

        super.paintComponent(g);
    }
}