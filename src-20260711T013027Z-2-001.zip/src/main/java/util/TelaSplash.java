package util;

import javax.swing.*;
import java.awt.*;

public class TelaSplash extends JWindow {

    private JProgressBar barra;

    public TelaSplash(JFrame proximaTela) {

        JPanel painel = new JPanel(new BorderLayout());
        painel.setBackground(new Color(15, 50, 20));
        painel.setBorder(
                BorderFactory.createLineBorder(
                        new Color(100, 220, 100), 3));

        // Logo
        JLabel lblLogo = new JLabel("", SwingConstants.CENTER);

        try {
            ImageIcon logo = new ImageIcon("src/main/java/img/logo.png");

            Image img = logo.getImage().getScaledInstance(
                    220,
                    90,
                    Image.SCALE_SMOOTH);

            lblLogo.setIcon(new ImageIcon(img));

        } catch (Exception e) {
            e.printStackTrace();
        }

        JLabel titulo = new JLabel(
                "BIO TECH",
                SwingConstants.CENTER);

        titulo.setFont(new Font("Segoe UI", Font.BOLD, 38));
        titulo.setForeground(new Color(100, 220, 100));

        JLabel sub = new JLabel(
                "Sistema de Gestão Agricola",
                SwingConstants.CENTER);

        sub.setFont(new Font("Segoe UI", Font.BOLD, 18));
        sub.setForeground(new Color(180, 220, 180));

        barra = new JProgressBar(0, 100);
        barra.setStringPainted(true);
        barra.setString("Carregando...");
        barra.setForeground(new Color(30, 180, 50));
        barra.setBackground(new Color(25, 35, 25));

        JLabel rodape = new JLabel(
                "Bio Tech - Projeto Agricultor FAETEC 2026",
                SwingConstants.CENTER);

        rodape.setForeground(new Color(120, 180, 120));

        JPanel centro = new JPanel(new GridLayout(3, 1));
        centro.setBackground(new Color(15, 50, 20));

        centro.add(lblLogo);
        centro.add(titulo);
        centro.add(sub);

        JPanel sul = new JPanel(new BorderLayout());
        sul.setBackground(new Color(15, 50, 20));
        sul.setBorder(
                BorderFactory.createEmptyBorder(
                        10, 20, 15, 20));

        sul.add(barra, BorderLayout.CENTER);
        sul.add(rodape, BorderLayout.SOUTH);

        painel.add(centro, BorderLayout.CENTER);
        painel.add(sul, BorderLayout.SOUTH);

        setContentPane(painel);

        setSize(600, 350);
        setLocationRelativeTo(null);

        iniciarCarregamento(proximaTela);
    }

    private void iniciarCarregamento(JFrame proximaTela) {

        setVisible(true);

        new Thread(() -> {

            try {

                for (int i = 0; i <= 100; i++) {

                    final int valor = i;

                    SwingUtilities.invokeLater(() ->
                            barra.setValue(valor));

                    Thread.sleep(25);
                }

                SwingUtilities.invokeLater(() -> {

                    dispose();

                    if (proximaTela != null) {
                        proximaTela.setVisible(true);
                    }

                });

            } catch (Exception e) {
                e.printStackTrace();
            }

        }).start();
    }
}