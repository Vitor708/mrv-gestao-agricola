package model;

import java.util.Date;

public class Colheita {

    private int idColheita;
    private Date dataColheita;
    private int quantidade;
    private int idPlantio;

    public Colheita() {}

    public Colheita(int idColheita, Date dataColheita,
                    int quantidade, int idPlantio) {
        this.idColheita   = idColheita;
        this.dataColheita = dataColheita;
        this.quantidade   = quantidade;
        this.idPlantio    = idPlantio;
    }

    public int getIdColheita() { return idColheita; }
    public void setIdColheita(int idColheita) { this.idColheita = idColheita; }

    public Date getDataColheita() { return dataColheita; }
    public void setDataColheita(Date dataColheita) { this.dataColheita = dataColheita; }

    public int getQuantidade() { return quantidade; }
    public void setQuantidade(int quantidade) { this.quantidade = quantidade; }

    public int getIdPlantio() { return idPlantio; }
    public void setIdPlantio(int idPlantio) { this.idPlantio = idPlantio; }
}