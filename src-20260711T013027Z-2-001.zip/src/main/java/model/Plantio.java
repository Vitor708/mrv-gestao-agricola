    package model;

    import java.util.Date;

    public class Plantio {

        private int idPlantio;
        private Date dataPlantio;
        private int areaPlantada;
        private int idCultura;
        private int idFazenda;

        public Plantio() {}

        public Plantio(int idPlantio, Date dataPlantio, int areaPlantada,
                       int idCultura, int idFazenda) {
            this.idPlantio    = idPlantio;
            this.dataPlantio  = dataPlantio;
            this.areaPlantada = areaPlantada;
            this.idCultura    = idCultura;
            this.idFazenda    = idFazenda;
        }

        public int getIdPlantio() { return idPlantio; }
        public void setIdPlantio(int idPlantio) { this.idPlantio = idPlantio; }

        public Date getDataPlantio() { return dataPlantio; }
        public void setDataPlantio(Date dataPlantio) { this.dataPlantio = dataPlantio; }

        public int getAreaPlantada() { return areaPlantada; }
        public void setAreaPlantada(int areaPlantada) { this.areaPlantada = areaPlantada; }

        public int getIdCultura() { return idCultura; }
        public void setIdCultura(int idCultura) { this.idCultura = idCultura; }

        public int getIdFazenda() { return idFazenda; }
        public void setIdFazenda(int idFazenda) { this.idFazenda = idFazenda; }
    }
