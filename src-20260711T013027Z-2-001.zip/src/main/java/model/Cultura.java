package model;
public class Cultura {
    private int idCultura;
    private String nome;
    private String tipo;
    private String unidade;
    private java.util.Date dataValidadeSemente;

    public Cultura() {}
    public Cultura(int idCultura, String nome, String tipo) {
        this.idCultura = idCultura;
        this.nome      = nome;
        this.tipo      = tipo;
    }
    public int getIdCultura() { return idCultura; }
    public void setIdCultura(int idCultura) { this.idCultura = idCultura; }
    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }
    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }
    public String getUnidade() { return unidade; }
    public void setUnidade(String unidade) { this.unidade = unidade; }
    public java.util.Date getDataValidadeSemente() { return dataValidadeSemente; }
    public void setDataValidadeSemente(java.util.Date dataValidadeSemente) { this.dataValidadeSemente = dataValidadeSemente; }
    private Integer idFazenda;

public Integer getIdFazenda() { return idFazenda; }
public void setIdFazenda(Integer idFazenda) { this.idFazenda = idFazenda; }
}