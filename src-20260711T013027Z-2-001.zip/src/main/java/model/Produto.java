package model;

public class Produto {

    private int idProduto;
    private String nome;
    private int unidade;
    private double preco;
    private int idCultura;

    public Produto() {}

    public Produto(int idProduto, String nome, int unidade,
                   double preco, int idCultura) {
        this.idProduto = idProduto;
        this.nome      = nome;
        this.unidade   = unidade;
        this.preco     = preco;
        this.idCultura = idCultura;
    }

    public int getIdProduto() { return idProduto; }
    public void setIdProduto(int idProduto) { this.idProduto = idProduto; }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public int getUnidade() { return unidade; }
    public void setUnidade(int unidade) { this.unidade = unidade; }

    public double getPreco() { return preco; }
    public void setPreco(double preco) { this.preco = preco; }

    public int getIdCultura() { return idCultura; }
    public void setIdCultura(int idCultura) { this.idCultura = idCultura; }
}