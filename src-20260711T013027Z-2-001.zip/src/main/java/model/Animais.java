package model;

public class Animais {
    private int idAnimais;
    private String especies;
    private long codigo;
    private long quantidade;
    private String raca;
    private String sexo;
    private double pesoAtual;
    private String status;
    private int idFazenda;

    public Animais() {}

    public Animais(int idAnimais, String especies, long codigo,
                   long quantidade, String raca, String sexo,
                   double pesoAtual, String status, int idFazenda) {
        this.idAnimais  = idAnimais;
        this.especies   = especies;
        this.codigo     = codigo;
        this.quantidade = quantidade;
        this.raca       = raca;
        this.sexo       = sexo;
        this.pesoAtual  = pesoAtual;
        this.status     = status;
        this.idFazenda  = idFazenda;
    }

    public int getIdAnimais() { return idAnimais; }
    public void setIdAnimais(int idAnimais) { this.idAnimais = idAnimais; }

    public String getEspecies() { return especies; }
    public void setEspecies(String especies) { this.especies = especies; }

    public long getCodigo() { return codigo; }
    public void setCodigo(long codigo) { this.codigo = codigo; }

    public long getQuantidade() { return quantidade; }
    public void setQuantidade(long quantidade) { this.quantidade = quantidade; }

    public String getRaca() { return raca; }
    public void setRaca(String raca) { this.raca = raca; }

    public String getSexo() { return sexo; }
    public void setSexo(String sexo) { this.sexo = sexo; }

    public double getPesoAtual() { return pesoAtual; }
    public void setPesoAtual(double pesoAtual) { this.pesoAtual = pesoAtual; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public int getIdFazenda() { return idFazenda; }
    public void setIdFazenda(int idFazenda) { this.idFazenda = idFazenda; }
}