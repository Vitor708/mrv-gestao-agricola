package model;

public class Fazenda {

    private int idFazenda;
    private int idUsuario;
    private String nome;
    private String proprietario;
    private String cep;
    private double areaHectares;
    private String estado;
    private String cidade;
    private String status;

    public Fazenda() {
    }

    public Fazenda(int idFazenda,
                   int idUsuario,
                   String nome,
                   String proprietario,
                   String cep,
                   double areaHectares,
                   String estado,
                   String cidade,
                   String status) {

        this.idFazenda = idFazenda;
        this.idUsuario = idUsuario;
        this.nome = nome;
        this.proprietario = proprietario;
        this.cep = cep;
        this.areaHectares = areaHectares;
        this.estado = estado;
        this.cidade = cidade;
        this.status = status;
    }

    public int getIdFazenda() {
        return idFazenda;
    }

    public void setIdFazenda(int idFazenda) {
        this.idFazenda = idFazenda;
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getProprietario() {
        return proprietario;
    }

    public void setProprietario(String proprietario) {
        this.proprietario = proprietario;
    }

    public String getCep() {
        return cep;
    }

    public void setCep(String cep) {
        this.cep = cep;
    }

    public double getAreaHectares() {
        return areaHectares;
    }

    public void setAreaHectares(double areaHectares) {
        this.areaHectares = areaHectares;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    private java.sql.Timestamp dataCadastro;

public java.sql.Timestamp getDataCadastro() {
    return dataCadastro;
}
public void setDataCadastro(java.sql.Timestamp dataCadastro) {
    this.dataCadastro = dataCadastro;
}
}