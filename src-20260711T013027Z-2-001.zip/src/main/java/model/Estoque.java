    package model;

    import java.util.Date;

    public class Estoque {
        private int idEstoque;
        private int idProduto;
        private int quantidade;
        private Date validade;

        public Estoque() {}

        public Estoque(int idEstoque, int idProduto, int quantidade, Date validade) {
            this.idEstoque  = idEstoque;
            this.idProduto  = idProduto;
            this.quantidade = quantidade;
            this.validade   = validade;
        }

        public int getIdEstoque() { return idEstoque; }
        public void setIdEstoque(int idEstoque) { this.idEstoque = idEstoque; }

        public int getIdProduto() { return idProduto; }
        public void setIdProduto(int idProduto) { this.idProduto = idProduto; }

        public int getQuantidade() { return quantidade; }
        public void setQuantidade(int quantidade) { this.quantidade = quantidade; }

        public Date getValidade() { return validade; }
        public void setValidade(Date validade) { this.validade = validade; }
        private int idFazenda;

    public int getIdFazenda() {
        return idFazenda;
    }

    public void setIdFazenda(int idFazenda) {
        this.idFazenda = idFazenda;
    }
    }