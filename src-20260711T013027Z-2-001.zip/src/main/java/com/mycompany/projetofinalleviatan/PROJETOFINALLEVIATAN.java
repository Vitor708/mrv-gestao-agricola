/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.projetofinalleviatan;

/**
 *
 * @author VT
 */
public class PROJETOFINALLEVIATAN {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
