package dao;

import connection.Conexao;
import model.Colheita;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ColheitaDAO {

    private final Connection conn;

    public ColheitaDAO() {
        this.conn = Conexao.getConexao();
    }
public int contar() {
    String sql = "SELECT COUNT(*) FROM colheita";
    try {
        PreparedStatement stmt = conn.prepareStatement(sql);
        ResultSet rs = stmt.executeQuery();
        if (rs.next()) return rs.getInt(1);
    } catch (SQLException e) {
        System.out.println("Erro ao contar colheitas: " + e.getMessage());
    }
    return 0;
}
    public boolean cadastrar(Colheita c) {
        String sql = "INSERT INTO colheita (dataColheita, quantidade, idPlantio) "
                   + "VALUES (?, ?, ?)";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setDate(1, new java.sql.Date(c.getDataColheita().getTime()));
            stmt.setInt(2, c.getQuantidade());
            stmt.setInt(3, c.getIdPlantio());
            stmt.executeUpdate();
            stmt.close();
            return true;
        } catch (SQLException e) {
            System.out.println("Erro ao cadastrar colheita: " + e.getMessage());
            return false;
        }
    }

    public List<Colheita> listar() {
        List<Colheita> lista = new ArrayList<>();
        String sql = "SELECT * FROM colheita";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Colheita c = new Colheita();
                c.setIdColheita(rs.getInt("idColheita"));
                c.setDataColheita(rs.getDate("dataColheita"));
                c.setQuantidade(rs.getInt("quantidade"));
                c.setIdPlantio(rs.getInt("idPlantio"));
                lista.add(c);
            }
            rs.close();
            stmt.close();
        } catch (SQLException e) {
            System.out.println("Erro ao listar colheitas: " + e.getMessage());
        }
        return lista;
    }

    public boolean atualizar(Colheita c) {
        String sql = "UPDATE colheita SET dataColheita=?, quantidade=?, "
                   + "idPlantio=? WHERE idColheita=?";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setDate(1, new java.sql.Date(c.getDataColheita().getTime()));
            stmt.setInt(2, c.getQuantidade());
            stmt.setInt(3, c.getIdPlantio());
            stmt.setInt(4, c.getIdColheita());
            int linhas = stmt.executeUpdate();
            stmt.close();
            return linhas > 0;
        } catch (SQLException e) {
            System.out.println("Erro ao atualizar colheita: " + e.getMessage());
            return false;
        }
    }

    public boolean deletar(int idColheita) {
        String sql = "DELETE FROM colheita WHERE idColheita=?";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, idColheita);
            int linhas = stmt.executeUpdate();
            stmt.close();
            return linhas > 0;
        } catch (SQLException e) {
            System.out.println("Erro ao deletar colheita: " + e.getMessage());
            return false;
        }
    }
    public int contarPorUsuario(int idUsuario) {
    String sql = "SELECT COUNT(*) FROM colheita c "
               + "JOIN plantio p ON c.idPlantio = p.idPlantio "
               + "JOIN fazenda f ON p.idFazenda = f.idFazenda "
               + "WHERE f.idUsuario = ?";
    try {
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setInt(1, idUsuario);
        ResultSet rs = stmt.executeQuery();
        if (rs.next()) return rs.getInt(1);
    } catch (SQLException e) {
        System.out.println("Erro ao contar colheitas do usuario: " + e.getMessage());
    }
    return 0;
}

public List<Colheita> listarPorUsuario(int idUsuario) {
    List<Colheita> lista = new ArrayList<>();
    String sql = "SELECT c.* FROM colheita c "
               + "JOIN plantio p ON c.idPlantio = p.idPlantio "
               + "JOIN fazenda f ON p.idFazenda = f.idFazenda "
               + "WHERE f.idUsuario = ?";
    try {
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setInt(1, idUsuario);
        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
            Colheita c = new Colheita();
            c.setIdColheita(rs.getInt("idColheita"));
            c.setDataColheita(rs.getDate("dataColheita"));
            c.setQuantidade(rs.getInt("quantidade"));
            c.setIdPlantio(rs.getInt("idPlantio"));
            lista.add(c);
        }
        rs.close();
        stmt.close();
    } catch (SQLException e) {
        System.out.println("Erro ao listar colheitas do usuario: " + e.getMessage());
    }
    return lista;
}
public List<Object[]> listarRelatorioPorUsuario(int idUsuario) {
    List<Object[]> lista = new ArrayList<>();
    String sql = "SELECT c.idColheita, c.dataColheita, c.quantidade, p.dataPlantio, cu.nome AS cultura, f.nome AS fazenda "
               + "FROM colheita c "
               + "JOIN plantio p ON c.idPlantio = p.idPlantio "
               + "JOIN cultura cu ON p.idCultura = cu.idCultura "
               + "JOIN fazenda f ON p.idFazenda = f.idFazenda "
               + "WHERE f.idUsuario = ? "
               + "ORDER BY c.dataColheita DESC";
    try {
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setInt(1, idUsuario);
        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
            Object[] linha = new Object[6];
            linha[0] = rs.getInt("idColheita");
            linha[1] = rs.getDate("dataColheita");
            linha[2] = rs.getInt("quantidade");
            linha[3] = rs.getDate("dataPlantio");
            linha[4] = rs.getString("cultura");
            linha[5] = rs.getString("fazenda");
            lista.add(linha);
        }
        rs.close();
        stmt.close();
    } catch (SQLException e) {
        System.out.println("Erro ao gerar relatorio de colheitas: " + e.getMessage());
    }
    return lista;
}
public Colheita buscarPorId(int idColheita) {
    String sql = "SELECT * FROM colheita WHERE idColheita = ?";
    try {
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setInt(1, idColheita);
        ResultSet rs = stmt.executeQuery();
        if (rs.next()) {
            Colheita c = new Colheita();
            c.setIdColheita(rs.getInt("idColheita"));
            c.setDataColheita(rs.getDate("dataColheita"));
            c.setQuantidade(rs.getInt("quantidade"));
            c.setIdPlantio(rs.getInt("idPlantio"));
            rs.close();
            stmt.close();
            return c;
        }
        rs.close();
        stmt.close();
    } catch (SQLException e) {
        System.out.println("Erro ao buscar colheita por id: " + e.getMessage());
    }
    return null;
}
}