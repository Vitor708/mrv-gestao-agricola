package dao;

import connection.Conexao;
import model.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UsuarioDAO {

    private final Connection conn;

    public UsuarioDAO() {
        this.conn = Conexao.getConexao();
    }

    public boolean cadastrar(Usuario u) {
        String sql = "INSERT INTO usuarios (nome, email, senha, cpf, telefone) "
                   + "VALUES (?, ?, ?, ?, ?)";
        try {
            String senhaCriptografada = org.mindrot.jbcrypt.BCrypt.hashpw(
                u.getSenha(), org.mindrot.jbcrypt.BCrypt.gensalt()
            );
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, u.getNome());
                stmt.setString(2, u.getEmail());
                stmt.setString(3, senhaCriptografada);
                stmt.setString(4, u.getCpf());
                stmt.setString(5, u.getTelefone());
                stmt.executeUpdate();
            }
            return true;
        } catch (SQLException e) {
            System.out.println("Erro ao cadastrar usuário: " + e.getMessage());
            return false;
        }
    }

    public Usuario login(String emailOuCpf, String senha) {
        String sql = "SELECT * FROM usuarios WHERE email = ? OR cpf = ?";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, emailOuCpf);
            stmt.setString(2, emailOuCpf);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                String senhaBanco = rs.getString("senha");
                if (org.mindrot.jbcrypt.BCrypt.checkpw(senha, senhaBanco)) {
                    Usuario u = new Usuario();
                    u.setId(rs.getInt("id"));
                    u.setNome(rs.getString("nome"));
                    u.setEmail(rs.getString("email"));
                    u.setSenha(rs.getString("senha"));
                    u.setCpf(rs.getString("cpf"));
                    u.setTelefone(rs.getString("telefone"));
                    rs.close();
                    stmt.close();
                    return u;
                }
            }
        } catch (SQLException e) {
            System.out.println("Erro ao fazer login: " + e.getMessage());
        }
        return null;
    }

    public boolean alterarSenha(String email, String novaSenha) {
        String sql = "UPDATE usuarios SET senha = ? WHERE email = ?";
        try {
            String senhaCriptografada = org.mindrot.jbcrypt.BCrypt.hashpw(
                novaSenha, org.mindrot.jbcrypt.BCrypt.gensalt()
            );
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, senhaCriptografada);
            stmt.setString(2, email);
            int linhas = stmt.executeUpdate();
            stmt.close();
            return linhas > 0;
        } catch (Exception e) {
            System.out.println("Erro ao alterar senha: " + e.getMessage());
            return false;
        }
    }

    public boolean emailExiste(String email) {
        String sql = "SELECT id FROM usuarios WHERE email = ?";
        try {
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, email);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        return true;
                    }
                }
            }
        } catch (SQLException e) {
            System.out.println("Erro ao verificar email: " + e.getMessage());
        }
        return false;
    }
    public boolean cpfExiste(String cpf) {
    String sql = "SELECT id FROM usuarios WHERE cpf = ?";
    try {
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, cpf);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return true;
                }
            }
        }
    } catch (SQLException e) {
        System.out.println("Erro ao verificar CPF: " + e.getMessage());
    }
    return false;
}
}
