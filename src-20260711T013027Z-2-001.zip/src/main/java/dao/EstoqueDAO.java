package dao;

import connection.Conexao;
import model.Estoque;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class EstoqueDAO {

    private final Connection conn;

    public EstoqueDAO() {
        this.conn = Conexao.getConexao();
    }

    public int contar() {
        String sql = "SELECT COUNT(*) FROM estoque";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            System.out.println("Erro ao contar estoque: " + e.getMessage());
        }
        return 0;
    }

    public int contarPorUsuario(int idUsuario) {
        String sql = "SELECT COUNT(*) FROM estoque e "
                   + "JOIN fazenda f ON e.idFazenda = f.idFazenda "
                   + "WHERE f.idUsuario = ?";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, idUsuario);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            System.out.println("Erro ao contar estoque do usuario: " + e.getMessage());
        }
        return 0;
    }

 public boolean cadastrar(Estoque e) {
    String sql = "INSERT INTO estoque (idProduto, quantidade, validade, idFazenda) "
               + "VALUES (?, ?, ?, ?)";
    try {
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setInt(1, e.getIdProduto());
        stmt.setInt(2, e.getQuantidade());
        stmt.setDate(3, e.getValidade() != null ? new java.sql.Date(e.getValidade().getTime()) : null);
        stmt.setInt(4, e.getIdFazenda());
        stmt.executeUpdate();
        stmt.close();
        return true;
    } catch (SQLException ex) {
        System.out.println("Erro ao cadastrar estoque: " + ex.getMessage());
        return false;
    }

    }

    public List<Estoque> listar() {
        List<Estoque> lista = new ArrayList<>();
        String sql = "SELECT * FROM estoque";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Estoque e = new Estoque();
                e.setIdEstoque(rs.getInt("idEstoque"));
                e.setIdProduto(rs.getInt("idProduto"));
                e.setQuantidade(rs.getInt("quantidade"));
                e.setValidade(rs.getDate("validade"));
                e.setIdFazenda(rs.getInt("idFazenda"));
                lista.add(e);
            }
            rs.close();
            stmt.close();
        } catch (SQLException ex) {
            System.out.println("Erro ao listar estoque: " + ex.getMessage());
        }
        return lista;
    }

    public List<Estoque> listarPorUsuario(int idUsuario) {
        List<Estoque> lista = new ArrayList<>();
        String sql = "SELECT e.* FROM estoque e "
                   + "JOIN fazenda f ON e.idFazenda = f.idFazenda "
                   + "WHERE f.idUsuario = ?";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, idUsuario);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Estoque e = new Estoque();
                e.setIdEstoque(rs.getInt("idEstoque"));
                e.setIdProduto(rs.getInt("idProduto"));
                e.setQuantidade(rs.getInt("quantidade"));
                e.setValidade(rs.getDate("validade"));
                e.setIdFazenda(rs.getInt("idFazenda"));
                lista.add(e);
            }
            rs.close();
            stmt.close();
        } catch (SQLException e) {
            System.out.println("Erro ao listar estoque do usuario: " + e.getMessage());
        }
        return lista;
    }

    public boolean atualizar(Estoque e) {
        String sql = "UPDATE estoque SET idProduto=?, quantidade=?, validade=?, idFazenda=? "
                   + "WHERE idEstoque=?";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, e.getIdProduto());
            stmt.setInt(2, e.getQuantidade());
            stmt.setDate(3, e.getValidade() != null ? new java.sql.Date(e.getValidade().getTime()) : null);
            stmt.setInt(4, e.getIdFazenda());
            stmt.setInt(5, e.getIdEstoque());
            int linhas = stmt.executeUpdate();
            stmt.close();
            return linhas > 0;
        } catch (SQLException ex) {
            System.out.println("Erro ao atualizar estoque: " + ex.getMessage());
            return false;
        }
    }

    public boolean deletar(int idEstoque) {
        String sql = "DELETE FROM estoque WHERE idEstoque=?";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, idEstoque);
            int linhas = stmt.executeUpdate();
            stmt.close();
            return linhas > 0;
        } catch (SQLException ex) {
            System.out.println("Erro ao deletar estoque: " + ex.getMessage());
            return false;
        }
    }

    public int consultarQuantidadeTotal(int idProduto) {
        String sql = "SELECT SUM(quantidade) AS total FROM estoque WHERE idProduto = ?";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, idProduto);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("total");
            }
            rs.close();
            stmt.close();
        } catch (SQLException e) {
            System.out.println("Erro ao consultar quantidade: " + e.getMessage());
        }
        return 0;
    }

    public boolean baixarEstoque(int idProduto, int idFazenda, int quantidadeSaida) {
        String sqlSelect = "SELECT idEstoque, quantidade FROM estoque "
                          + "WHERE idProduto = ? AND idFazenda = ? AND quantidade > 0 ORDER BY validade ASC";
        String sqlUpdate = "UPDATE estoque SET quantidade = ? WHERE idEstoque = ?";

        try {
            conn.setAutoCommit(false);

            List<int[]> atualizacoes = new ArrayList<>();
            PreparedStatement stmtSelect = conn.prepareStatement(sqlSelect);
            stmtSelect.setInt(1, idProduto);
            stmtSelect.setInt(2, idFazenda);
            ResultSet rs = stmtSelect.executeQuery();

            int restante = quantidadeSaida;
            while (rs.next() && restante > 0) {
                int idEstoque = rs.getInt("idEstoque");
                int qtdDisponivel = rs.getInt("quantidade");
                int qtdRetirar = Math.min(qtdDisponivel, restante);
                atualizacoes.add(new int[]{idEstoque, qtdDisponivel - qtdRetirar});
                restante -= qtdRetirar;
            }
            rs.close();
            stmtSelect.close();

            if (restante > 0) {
                conn.rollback();
                return false; // estoque insuficiente
            }

            PreparedStatement stmtUpdate = conn.prepareStatement(sqlUpdate);
            for (int[] atualizacao : atualizacoes) {
                stmtUpdate.setInt(1, atualizacao[1]);
                stmtUpdate.setInt(2, atualizacao[0]);
                stmtUpdate.executeUpdate();
            }
            stmtUpdate.close();

            conn.commit();
            return true;
        } catch (SQLException e) {
            try { conn.rollback(); } catch (SQLException ex) { }
            System.out.println("Erro ao dar baixa no estoque: " + e.getMessage());
            return false;
        } finally {
            try { conn.setAutoCommit(true); } catch (SQLException e) { }
        }
    }
    public List<Estoque> buscarPorProdutoEFazenda(int idProduto, int idFazenda) {
    List<Estoque> lista = new ArrayList<>();
    String sql = "SELECT * FROM estoque WHERE idProduto = ? AND idFazenda = ? AND quantidade > 0 ORDER BY validade ASC";
    try {
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setInt(1, idProduto);
        stmt.setInt(2, idFazenda);
        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
            Estoque e = new Estoque();
            e.setIdEstoque(rs.getInt("idEstoque"));
            e.setIdProduto(rs.getInt("idProduto"));
            e.setQuantidade(rs.getInt("quantidade"));
            e.setValidade(rs.getDate("validade"));
            e.setIdFazenda(rs.getInt("idFazenda"));
            lista.add(e);
        }
        rs.close();
        stmt.close();
    } catch (SQLException e) {
        System.out.println("Erro ao buscar estoque por produto e fazenda: " + e.getMessage());
    }
    return lista;
}
    public List<Object[]> listarRelatorioPorUsuario(int idUsuario) {
    List<Object[]> lista = new ArrayList<>();
    String sql = "SELECT e.idEstoque, pr.nome AS produto, e.quantidade, e.validade, f.nome AS fazenda "
               + "FROM estoque e "
               + "JOIN produto pr ON e.idProduto = pr.idProduto "
               + "JOIN fazenda f ON e.idFazenda = f.idFazenda "
               + "WHERE f.idUsuario = ? "
               + "ORDER BY e.validade ASC";
    try {
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setInt(1, idUsuario);
        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
            Object[] linha = new Object[5];
            linha[0] = rs.getInt("idEstoque");
            linha[1] = rs.getString("produto");
            linha[2] = rs.getInt("quantidade");
            linha[3] = rs.getDate("validade");
            linha[4] = rs.getString("fazenda");
            lista.add(linha);
        }
        rs.close();
        stmt.close();
    } catch (SQLException e) {
        System.out.println("Erro ao gerar relatorio de estoque: " + e.getMessage());
    }
    return lista;
}
    public Estoque buscarPorId(int idEstoque) {
    String sql = "SELECT * FROM estoque WHERE idEstoque = ?";
    try {
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setInt(1, idEstoque);
        ResultSet rs = stmt.executeQuery();
        if (rs.next()) {
            Estoque e = new Estoque();
            e.setIdEstoque(rs.getInt("idEstoque"));
            e.setIdProduto(rs.getInt("idProduto"));
            e.setQuantidade(rs.getInt("quantidade"));
            e.setValidade(rs.getDate("validade"));
            e.setIdFazenda(rs.getInt("idFazenda"));
            rs.close();
            stmt.close();
            return e;
        }
        rs.close();
        stmt.close();
    } catch (SQLException ex) {
        System.out.println("Erro ao buscar estoque por id: " + ex.getMessage());
    }
    return null;
}
}