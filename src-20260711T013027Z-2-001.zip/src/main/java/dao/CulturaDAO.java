package dao;
import connection.Conexao;
import model.Cultura;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
public class CulturaDAO {
    private final Connection conn;
    public CulturaDAO() {
        this.conn = Conexao.getConexao();
    }

    public int contar() {
        String sql = "SELECT COUNT(*) FROM cultura";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            System.out.println("Erro ao contar culturas: " + e.getMessage());
        }
        return 0;
    }

    public List<Cultura> listar() {
        List<Cultura> lista = new ArrayList<>();
        String sql = "SELECT * FROM cultura";
        try {
            try (PreparedStatement stmt = conn.prepareStatement(sql); ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Cultura c = new Cultura();
                    c.setIdCultura(rs.getInt("idCultura"));
                    c.setNome(rs.getString("nome"));
                    c.setTipo(rs.getString("tipo"));
                    c.setUnidade(rs.getString("unidade"));
                    c.setDataValidadeSemente(rs.getDate("dataValidadeSemente"));
                    int idFazenda = rs.getInt("idFazenda");
                    c.setIdFazenda(rs.wasNull() ? null : idFazenda);
                    lista.add(c);
                }
            }
        } catch (SQLException e) {
            System.out.println("Erro ao listar culturas: " + e.getMessage());
        }
        return lista;
    }

    public List<Cultura> listarPorUsuario(int idUsuario) {
        List<Cultura> lista = new ArrayList<>();
        String sql = "SELECT c.* FROM cultura c "
                   + "JOIN fazenda f ON c.idFazenda = f.idFazenda "
                   + "WHERE f.idUsuario = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idUsuario);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Cultura c = new Cultura();
                    c.setIdCultura(rs.getInt("idCultura"));
                    c.setNome(rs.getString("nome"));
                    c.setTipo(rs.getString("tipo"));
                    c.setUnidade(rs.getString("unidade"));
                    c.setDataValidadeSemente(rs.getDate("dataValidadeSemente"));
                    int idFazenda = rs.getInt("idFazenda");
                    c.setIdFazenda(rs.wasNull() ? null : idFazenda);
                    lista.add(c);
                }
            }
        } catch (SQLException e) {
            System.out.println("Erro ao listar culturas do usuario: " + e.getMessage());
        }
        return lista;
    }

    public boolean cadastrar(Cultura c) {
        String sql = "INSERT INTO cultura (nome, tipo, unidade, dataValidadeSemente, idFazenda) VALUES (?, ?, ?, ?, ?)";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, c.getNome());
            stmt.setString(2, c.getTipo());
            stmt.setString(3, c.getUnidade());
            stmt.setDate(4, c.getDataValidadeSemente() != null ? new java.sql.Date(c.getDataValidadeSemente().getTime()) : null);
            if (c.getIdFazenda() != null) {
                stmt.setInt(5, c.getIdFazenda());
            } else {
                stmt.setNull(5, java.sql.Types.INTEGER);
            }
            stmt.executeUpdate();
            stmt.close();
            return true;
        } catch (SQLException e) {
            System.out.println("Erro ao cadastrar cultura: " + e.getMessage());
            return false;
        }
    }

    public Cultura buscarPorNome(String nome) {
        String sql = "SELECT * FROM cultura WHERE nome = ? ORDER BY idCultura DESC LIMIT 1";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, nome);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Cultura c = new Cultura();
                c.setIdCultura(rs.getInt("idCultura"));
                c.setNome(rs.getString("nome"));
                c.setTipo(rs.getString("tipo"));
                c.setUnidade(rs.getString("unidade"));
                c.setDataValidadeSemente(rs.getDate("dataValidadeSemente"));
                int idFazenda = rs.getInt("idFazenda");
                c.setIdFazenda(rs.wasNull() ? null : idFazenda);
                rs.close();
                stmt.close();
                return c;
            }
        } catch (SQLException e) {
            System.out.println("Erro ao buscar cultura: " + e.getMessage());
        }
        return null;
    }

    public Cultura buscarPorId(int idCultura) {
        String sql = "SELECT * FROM cultura WHERE idCultura = ?";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, idCultura);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Cultura c = new Cultura();
                c.setIdCultura(rs.getInt("idCultura"));
                c.setNome(rs.getString("nome"));
                c.setTipo(rs.getString("tipo"));
                c.setUnidade(rs.getString("unidade"));
                c.setDataValidadeSemente(rs.getDate("dataValidadeSemente"));
                int idFazenda = rs.getInt("idFazenda");
                c.setIdFazenda(rs.wasNull() ? null : idFazenda);
                rs.close();
                stmt.close();
                return c;
            }
        } catch (SQLException e) {
            System.out.println("Erro ao buscar cultura por id: " + e.getMessage());
        }
        return null;
    }

   public boolean deletar(int idCultura) {
    int confirma = javax.swing.JOptionPane.showConfirmDialog(null,
        "Tem certeza que deseja excluir esta cultura e todos os produtos vinculados a ela?",
        "Confirmar Exclusão", javax.swing.JOptionPane.YES_NO_OPTION);

    if (confirma != javax.swing.JOptionPane.YES_OPTION) return false;

    try {
        try (PreparedStatement stmt = conn.prepareStatement("DELETE FROM produto WHERE idCultura=?")) {
            stmt.setInt(1, idCultura);
            stmt.executeUpdate();
        }
        int linhas;
        try (PreparedStatement stmt = conn.prepareStatement("DELETE FROM cultura WHERE idCultura=?")) {
            stmt.setInt(1, idCultura);
            linhas = stmt.executeUpdate();
        }
        return linhas > 0;
    } catch (SQLException e) {
        System.out.println("Erro ao deletar cultura: " + e.getMessage());
        return false;
    }

    }

    public boolean atualizar(Cultura c) {
        String sql = "UPDATE cultura SET nome=?, tipo=?, unidade=?, dataValidadeSemente=?, idFazenda=? WHERE idCultura=?";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, c.getNome());
            stmt.setString(2, c.getTipo());
            stmt.setString(3, c.getUnidade());
            stmt.setDate(4, c.getDataValidadeSemente() != null ? new java.sql.Date(c.getDataValidadeSemente().getTime()) : null);
            if (c.getIdFazenda() != null) {
                stmt.setInt(5, c.getIdFazenda());
            } else {
                stmt.setNull(5, java.sql.Types.INTEGER);
            }
            stmt.setInt(6, c.getIdCultura());
            int linhas = stmt.executeUpdate();
            stmt.close();
            return linhas > 0;
        } catch (SQLException e) {
            System.out.println("Erro ao atualizar cultura: " + e.getMessage());
            return false;
        }
    }
}