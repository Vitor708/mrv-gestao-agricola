package dao;

import connection.Conexao;
import model.Fazenda;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class FazendaDAO {

    private final Connection conn;

    public FazendaDAO() {
        this.conn = Conexao.getConexao();
    }

    public int contar() {
        String sql = "SELECT COUNT(*) FROM fazenda";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return rs.getInt(1);
            }

        } catch (SQLException e) {
            System.out.println("Erro ao contar fazendas: " + e.getMessage());
        }

        return 0;
    }

    public boolean cadastrar(Fazenda f) {
        String sql = "INSERT INTO fazenda (nome, idUsuario, CEP, area_hectares, estado, cidade, status) "
                   + "VALUES (?, ?, ?, ?, ?, ?, ?)";
        try {
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, f.getNome());
                stmt.setInt(2, f.getIdUsuario());
                stmt.setString(3, f.getCep());
                stmt.setDouble(4, f.getAreaHectares());
                stmt.setString(5, f.getEstado());
                stmt.setString(6, f.getCidade());
                stmt.setString(7, f.getStatus()); 
                stmt.executeUpdate();
            }
            return true;
        } catch (SQLException e) {
            System.out.println("Erro ao cadastrar fazenda: " + e.getMessage());
            return false;
        }
    }   

    public List<Fazenda> listar() {
        List<Fazenda> lista = new ArrayList<>();
        String sql = "SELECT * FROM fazenda";

        try {
            try (PreparedStatement stmt = conn.prepareStatement(sql); ResultSet rs = stmt.executeQuery()) {
                
                while (rs.next()) {
                    Fazenda f = new Fazenda();
                    f.setIdFazenda(rs.getInt("idFazenda"));
                    f.setNome(rs.getString("nome"));
                    f.setCep(rs.getString("CEP"));
                    f.setAreaHectares(rs.getDouble("area_hectares"));
                    f.setEstado(rs.getString("estado"));
                    f.setCidade(rs.getString("cidade"));
                    f.setStatus(rs.getString("status"));
                    f.setIdUsuario(rs.getInt("idUsuario"));
                    f.setDataCadastro(rs.getTimestamp("dataCadastro"));
                    lista.add(f);
                }
                
            }

        } catch (SQLException e) {
            System.out.println("Erro ao listar fazendas: " + e.getMessage());
        }

        return lista;
    }

    public boolean atualizar(Fazenda f) {
        String sql = "UPDATE fazenda SET nome=?, idUsuario=?, CEP=?, "
                   + "area_hectares=?, estado=?, cidade=?, status=? WHERE idFazenda=?";

        try {
            int linhas;
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, f.getNome());
                stmt.setInt(2, f.getIdUsuario()); 
                stmt.setString(3, f.getCep());
                stmt.setDouble(4, f.getAreaHectares());
                stmt.setString(5, f.getEstado());
                stmt.setString(6, f.getCidade());
                stmt.setString(7, f.getStatus()); 
                stmt.setInt(8, f.getIdFazenda());
                linhas = stmt.executeUpdate();
            }

            return linhas > 0;

        } catch (SQLException e) {
            System.out.println("Erro ao atualizar fazenda: " + e.getMessage());
            return false;
        }
    }

    public boolean deletar(int idFazenda) {
        int confirma = javax.swing.JOptionPane.showConfirmDialog(null,
            "Tem certeza que deseja excluir esta fazenda e todos os dados vinculados a ela?",
            "Confirmar Exclusão", javax.swing.JOptionPane.YES_NO_OPTION);

        if (confirma != javax.swing.JOptionPane.YES_OPTION) return false;

        try {
            try (PreparedStatement stmt = conn.prepareStatement(
                    "DELETE FROM colheita WHERE idPlantio IN (SELECT idPlantio FROM plantio WHERE idFazenda=?)")) {
                stmt.setInt(1, idFazenda);
                stmt.executeUpdate();
            }
            try (PreparedStatement stmt = conn.prepareStatement("DELETE FROM plantio WHERE idFazenda=?")) {
                stmt.setInt(1, idFazenda);
                stmt.executeUpdate();
            }
            try (PreparedStatement stmt = conn.prepareStatement("DELETE FROM animais WHERE idFazenda=?")) {
                stmt.setInt(1, idFazenda);
                stmt.executeUpdate();
            }
            int linhas;
            try (PreparedStatement stmt = conn.prepareStatement("DELETE FROM fazenda WHERE idFazenda=?")) {
                stmt.setInt(1, idFazenda);
                linhas = stmt.executeUpdate();
            }
            return linhas > 0;

        } catch (SQLException e) {
            System.out.println("Erro ao deletar fazenda: " + e.getMessage());
            return false;
        }
    }

    public int contarPorEstado(String estado) {
        String sql = estado.equals("TODOS")
                ? "SELECT COUNT(*) FROM fazenda"
                : "SELECT COUNT(*) FROM fazenda WHERE estado=?";

        try {
            PreparedStatement stmt = conn.prepareStatement(sql);

            if (!estado.equals("TODOS")) {
                stmt.setString(1, estado);
            }

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return rs.getInt(1);
            }

        } catch (SQLException e) {
            System.out.println("Erro ao contar: " + e.getMessage());
        }

        return 0;
    }

    public double somarArea() {
        String sql = "SELECT SUM(area_hectares) FROM fazenda";

        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return rs.getDouble(1);
            }

        } catch (SQLException e) {
            System.out.println("Erro ao somar área: " + e.getMessage());
        }

        return 0;
    }

    public int contarPorStatus(String status) {
        String sql = "SELECT COUNT(*) FROM fazenda WHERE status=?";

        try {
            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setString(1, status);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return rs.getInt(1);
            }

        } catch (SQLException e) {
            System.out.println("Erro ao contar por status: " + e.getMessage());
        }

        return 0;
    }

    public List<Fazenda> listarPorUsuario(int idUsuario) {
        List<Fazenda> lista = new ArrayList<>();
        String sql = "SELECT * FROM fazenda WHERE idUsuario=?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idUsuario);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Fazenda f = new Fazenda();
                    f.setIdFazenda(rs.getInt("idFazenda"));
                    f.setNome(rs.getString("nome"));
                    f.setCep(rs.getString("CEP"));
                    f.setAreaHectares(rs.getDouble("area_hectares"));
                    f.setEstado(rs.getString("estado"));
                    f.setCidade(rs.getString("cidade"));
                    f.setStatus(rs.getString("status"));
                    f.setIdUsuario(rs.getInt("idUsuario"));
                    f.setDataCadastro(rs.getTimestamp("dataCadastro"));
                    lista.add(f);
                }
            }
        } catch (SQLException e) {
            System.out.println("Erro ao listar fazendas do usuario: " + e.getMessage());
        }

        return lista;
    }

    public int contarPorUsuario(int idUsuario) {
        String sql = "SELECT COUNT(*) FROM fazenda WHERE idUsuario=?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idUsuario);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        } catch (SQLException e) {
            System.out.println("Erro ao contar fazendas do usuario: " + e.getMessage());
        }
        return 0;
    }

    public model.Fazenda buscarPorId(int idFazenda) {
        String sql = "SELECT * FROM fazenda WHERE idFazenda = ?";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, idFazenda);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Fazenda f = new Fazenda();
                f.setIdFazenda(rs.getInt("idFazenda"));
                f.setNome(rs.getString("nome"));
                f.setCep(rs.getString("CEP"));
                f.setAreaHectares(rs.getDouble("area_hectares"));
                f.setEstado(rs.getString("estado"));
                f.setCidade(rs.getString("cidade"));
                f.setStatus(rs.getString("status"));
                f.setIdUsuario(rs.getInt("idUsuario"));
                f.setDataCadastro(rs.getTimestamp("dataCadastro"));
                rs.close();
                stmt.close();
                return f;
            }
        } catch (SQLException e) {
            System.out.println("Erro ao buscar fazenda: " + e.getMessage());
        }
        return null;
    }
}