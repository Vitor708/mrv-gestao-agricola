package dao;

import connection.Conexao;
import model.Produto;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ProdutoDAO {
    private final Connection conn;

    public ProdutoDAO() {
        this.conn = Conexao.getConexao();
    }

    public int contar() {
        String sql = "SELECT COUNT(*) FROM produto";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            System.out.println("Erro ao contar produtos: " + e.getMessage());
        }
        return 0;
    }

    public boolean cadastrar(Produto p) {
        String sql = "INSERT INTO produto (nome, unidade, preco, idCultura) "
                   + "VALUES (?, ?, ?, ?)";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, p.getNome());
            stmt.setInt(2, p.getUnidade());
            stmt.setDouble(3, p.getPreco());
            stmt.setInt(4, p.getIdCultura());
            stmt.executeUpdate();
            stmt.close();
            return true;
        } catch (SQLException e) {
            System.out.println("Erro ao cadastrar produto: " + e.getMessage());
            return false;
        }
    }

    public List<Produto> listar() {
        List<Produto> lista = new ArrayList<>();
        String sql = "SELECT * FROM produto";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Produto p = new Produto();
                p.setIdProduto(rs.getInt("idProduto"));
                p.setNome(rs.getString("nome"));
                p.setUnidade(rs.getInt("unidade"));
                p.setPreco(rs.getDouble("preco"));
                p.setIdCultura(rs.getInt("idCultura"));
                lista.add(p);
            }
            rs.close();
            stmt.close();
        } catch (SQLException e) {
            System.out.println("Erro ao listar produtos: " + e.getMessage());
        }
        return lista;
    }

    public boolean atualizar(Produto p) {
        String sql = "UPDATE produto SET nome=?, unidade=?, preco=?, idCultura=? "
                   + "WHERE idProduto=?";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, p.getNome());
            stmt.setInt(2, p.getUnidade());
            stmt.setDouble(3, p.getPreco());
            stmt.setInt(4, p.getIdCultura());
            stmt.setInt(5, p.getIdProduto());
            int linhas = stmt.executeUpdate();
            stmt.close();
            return linhas > 0;
        } catch (SQLException e) {
            System.out.println("Erro ao atualizar produto: " + e.getMessage());
            return false;
        }
    }

    public boolean deletar(int idProduto) {
        String sql = "DELETE FROM produto WHERE idProduto=?";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, idProduto);
            int linhas = stmt.executeUpdate();
            stmt.close();
            return linhas > 0;
        } catch (SQLException e) {
            System.out.println("Erro ao deletar produto: " + e.getMessage());
            return false;
        }
    }
    public Produto buscarPorIdCultura(int idCultura) {
    String sql = "SELECT * FROM produto WHERE idCultura = ? LIMIT 1";
    try {
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setInt(1, idCultura);
        ResultSet rs = stmt.executeQuery();
        if (rs.next()) {
            Produto p = new Produto();
            p.setIdProduto(rs.getInt("idProduto"));
            p.setNome(rs.getString("nome"));
            p.setUnidade(rs.getInt("unidade"));
            p.setPreco(rs.getDouble("preco"));
            p.setIdCultura(rs.getInt("idCultura"));
            rs.close();
            stmt.close();
            return p;
        }
        rs.close();
        stmt.close();
    } catch (SQLException ex) {
        System.out.println("Erro ao buscar produto por cultura: " + ex.getMessage());
    }
    return null;
}
}