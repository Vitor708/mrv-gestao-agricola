package dao;

import connection.Conexao;
import model.Animais;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class AnimaisDAO {

    private final Connection conn;

    public AnimaisDAO() {
        this.conn = Conexao.getConexao();
    }
public int contar() {
    String sql = "SELECT COUNT(*) FROM animais";
    try {
        PreparedStatement stmt = conn.prepareStatement(sql);
        ResultSet rs = stmt.executeQuery();
        if (rs.next()) return rs.getInt(1);
    } catch (SQLException e) {
        System.out.println("Erro ao contar animais: " + e.getMessage());
    }
    return 0;
}
 public boolean cadastrar(Animais a) {
    String sql = "INSERT INTO animais (especies, codigo, quantidade, raca, sexo, peso_atual, status, idFazenda) "
               + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    try {
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setString(1, a.getEspecies());
        stmt.setLong(2, a.getCodigo());
        stmt.setLong(3, a.getQuantidade());
        stmt.setString(4, a.getRaca());
        stmt.setString(5, a.getSexo());
        stmt.setDouble(6, a.getPesoAtual());
        stmt.setString(7, a.getStatus());
        stmt.setInt(8, a.getIdFazenda());
        stmt.executeUpdate();
        stmt.close();
        return true;
    } catch (SQLException e) {
        System.out.println("Erro ao cadastrar animal: " + e.getMessage());
        return false;
    }
}

    public List<Animais> listar() {
        List<Animais> lista = new ArrayList<>();
        String sql = "SELECT * FROM animais";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Animais a = new Animais();
                a.setIdAnimais(rs.getInt("idAnimais"));
                a.setEspecies(rs.getString("especies"));
                a.setCodigo(rs.getLong("codigo"));
                a.setQuantidade(rs.getLong("quantidade"));
                a.setRaca(rs.getString("raca"));
                a.setSexo(rs.getString("sexo"));
                a.setPesoAtual(rs.getDouble("peso_atual"));
                a.setStatus(rs.getString("status"));
                lista.add(a);
            }
            rs.close();
            stmt.close();
        } catch (SQLException e) {
            System.out.println("Erro ao listar animais: " + e.getMessage());
        }
        return lista;
    }

    public boolean deletar(int idAnimais) {
        String sql = "DELETE FROM animais WHERE idAnimais=?";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, idAnimais);
            int linhas = stmt.executeUpdate();
            stmt.close();
            return linhas > 0;
        } catch (SQLException e) {
            System.out.println("Erro ao deletar animal: " + e.getMessage());
            return false;
        }
    }
    public int contarPorUsuario(int idUsuario) {
    String sql = "SELECT COUNT(*) FROM animais a "
               + "JOIN fazenda f ON a.idFazenda = f.idFazenda "
               + "WHERE f.idUsuario = ?";
    try {
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setInt(1, idUsuario);
        ResultSet rs = stmt.executeQuery();
        if (rs.next()) return rs.getInt(1);
    } catch (SQLException e) {
        System.out.println("Erro ao contar animais do usuario: " + e.getMessage());
    }
    return 0;
}

public List<Animais> listarPorUsuario(int idUsuario) {
    List<Animais> lista = new ArrayList<>();
    String sql = "SELECT a.* FROM animais a "
               + "JOIN fazenda f ON a.idFazenda = f.idFazenda "
               + "WHERE f.idUsuario = ?";
    try {
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setInt(1, idUsuario);
        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
            Animais a = new Animais();
            a.setIdAnimais(rs.getInt("idAnimais"));
            a.setEspecies(rs.getString("especies"));
            a.setCodigo(rs.getLong("codigo"));
            a.setQuantidade(rs.getLong("quantidade"));
            a.setRaca(rs.getString("raca"));
            a.setSexo(rs.getString("sexo"));
            a.setPesoAtual(rs.getDouble("peso_atual"));
            a.setStatus(rs.getString("status"));
            a.setIdFazenda(rs.getInt("idFazenda"));
            lista.add(a);
        }
        rs.close();
        stmt.close();
    } catch (SQLException e) {
        System.out.println("Erro ao listar animais do usuario: " + e.getMessage());
    }
    return lista;
}
public boolean atualizar(Animais a) {
    String sql = "UPDATE animais SET especies=?, codigo=?, quantidade=?, raca=?, sexo=?, peso_atual=?, status=? WHERE idAnimais=?";
    try {
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setString(1, a.getEspecies());
        stmt.setLong(2, a.getCodigo());
        stmt.setLong(3, a.getQuantidade());
        stmt.setString(4, a.getRaca());
        stmt.setString(5, a.getSexo());
        stmt.setDouble(6, a.getPesoAtual());
        stmt.setString(7, a.getStatus());
        stmt.setInt(8, a.getIdAnimais());
        int linhas = stmt.executeUpdate();
        stmt.close();
        return linhas > 0;
    } catch (SQLException e) {
        System.out.println("Erro ao atualizar animal: " + e.getMessage());
        return false;
    }
}
public model.Animais buscarPorId(int idAnimais) {
    String sql = "SELECT * FROM animais WHERE idAnimais = ?";
    try {
        java.sql.PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setInt(1, idAnimais);
        java.sql.ResultSet rs = stmt.executeQuery();
        if (rs.next()) {
            model.Animais a = new model.Animais();
            a.setIdAnimais(rs.getInt("idAnimais"));
            a.setEspecies(rs.getString("especies"));
            a.setCodigo(rs.getLong("codigo"));
            a.setQuantidade(rs.getLong("quantidade"));
            a.setRaca(rs.getString("raca"));
            a.setSexo(rs.getString("sexo"));
            a.setPesoAtual(rs.getDouble("peso_atual"));
            a.setStatus(rs.getString("status"));
            a.setIdFazenda(rs.getInt("idFazenda"));
            rs.close();
            stmt.close();
            return a;
        }
    } catch (java.sql.SQLException e) {
        System.out.println("Erro ao buscar animal: " + e.getMessage());
    }
    return null;
}
}