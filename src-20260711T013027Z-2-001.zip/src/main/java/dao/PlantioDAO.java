package dao;

import connection.Conexao;
import model.Plantio;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PlantioDAO {

    private final Connection conn;

    public PlantioDAO() {
        this.conn = Conexao.getConexao();
    }
public int contar() {
    String sql = "SELECT COUNT(*) FROM plantio";
    try {
        PreparedStatement stmt = conn.prepareStatement(sql);
        ResultSet rs = stmt.executeQuery();
        if (rs.next()) return rs.getInt(1);
    } catch (SQLException e) {
        System.out.println("Erro ao contar plantios: " + e.getMessage());
    }
    return 0;
}
    public boolean cadastrar(Plantio p) {
        String sql = "INSERT INTO plantio (dataPlantio, areaPlantada, idCultura, idFazenda) "
                   + "VALUES (?, ?, ?, ?)";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setDate(1, new java.sql.Date(p.getDataPlantio().getTime()));
            stmt.setInt(2, p.getAreaPlantada());
            stmt.setInt(3, p.getIdCultura());
            stmt.setInt(4, p.getIdFazenda());
            stmt.executeUpdate();
            stmt.close();
            return true;
        } catch (SQLException e) {
            System.out.println("Erro ao cadastrar plantio: " + e.getMessage());
            return false;
        }
    }

    public List<Plantio> listar() {
        List<Plantio> lista = new ArrayList<>();
        String sql = "SELECT * FROM plantio";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Plantio p = new Plantio();
                p.setIdPlantio(rs.getInt("idPlantio"));
                p.setDataPlantio(rs.getDate("dataPlantio"));
                p.setAreaPlantada(rs.getInt("areaPlantada"));
                p.setIdCultura(rs.getInt("idCultura"));
                p.setIdFazenda(rs.getInt("idFazenda"));
                lista.add(p);
            }
            rs.close();
            stmt.close();
        } catch (SQLException e) {
            System.out.println("Erro ao listar plantios: " + e.getMessage());
        }
        return lista;
    }

    public boolean atualizar(Plantio p) {
        String sql = "UPDATE plantio SET dataPlantio=?, areaPlantada=?, "
                   + "idCultura=?, idFazenda=? WHERE idPlantio=?";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setDate(1, new java.sql.Date(p.getDataPlantio().getTime()));
            stmt.setInt(2, p.getAreaPlantada());
            stmt.setInt(3, p.getIdCultura());
            stmt.setInt(4, p.getIdFazenda());
            stmt.setInt(5, p.getIdPlantio());
            int linhas = stmt.executeUpdate();
            stmt.close();
            return linhas > 0;
        } catch (SQLException e) {
            System.out.println("Erro ao atualizar plantio: " + e.getMessage());
            return false;
        }
    }

    public boolean deletar(int idPlantio) {
        String sql = "DELETE FROM plantio WHERE idPlantio=?";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, idPlantio);
            int linhas = stmt.executeUpdate();
            stmt.close();
            return linhas > 0;
        } catch (SQLException e) {
            System.out.println("Erro ao deletar plantio: " + e.getMessage());
            return false;
        }
    }
    public int contarPorUsuario(int idUsuario) {
    String sql = "SELECT COUNT(*) FROM plantio p "
               + "JOIN fazenda f ON p.idFazenda = f.idFazenda "
               + "WHERE f.idUsuario = ?";
    try {
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setInt(1, idUsuario);
        ResultSet rs = stmt.executeQuery();
        if (rs.next()) return rs.getInt(1);
    } catch (SQLException e) {
        System.out.println("Erro ao contar plantios do usuario: " + e.getMessage());
    }
    return 0;
}

public List<Plantio> listarPorUsuario(int idUsuario) {
    List<Plantio> lista = new ArrayList<>();
    String sql = "SELECT p.* FROM plantio p "
               + "JOIN fazenda f ON p.idFazenda = f.idFazenda "
               + "WHERE f.idUsuario = ?";
    try {
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setInt(1, idUsuario);
        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
            Plantio p = new Plantio();
            p.setIdPlantio(rs.getInt("idPlantio"));
            p.setDataPlantio(rs.getDate("dataPlantio"));
            p.setAreaPlantada(rs.getInt("areaPlantada"));
            p.setIdCultura(rs.getInt("idCultura"));
            p.setIdFazenda(rs.getInt("idFazenda"));
            lista.add(p);
        }
        rs.close();
        stmt.close();
    } catch (SQLException e) {
        System.out.println("Erro ao listar plantios do usuario: " + e.getMessage());
    }
    return lista;
}
public List<Object[]> listarRelatorioPorUsuario(int idUsuario) {
    List<Object[]> lista = new ArrayList<>();
    String sql = "SELECT p.dataPlantio, p.areaPlantada, c.nome AS cultura, f.nome AS fazenda "
               + "FROM plantio p "
               + "JOIN cultura c ON p.idCultura = c.idCultura "
               + "JOIN fazenda f ON p.idFazenda = f.idFazenda "
               + "WHERE f.idUsuario = ? "
               + "ORDER BY p.dataPlantio DESC";
    try {
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setInt(1, idUsuario);
        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
            Object[] linha = new Object[4];
            linha[0] = rs.getDate("dataPlantio");
            linha[1] = rs.getInt("areaPlantada");
            linha[2] = rs.getString("cultura");
            linha[3] = rs.getString("fazenda");
            lista.add(linha);
        }
        rs.close();
        stmt.close();
    } catch (SQLException e) {
        System.out.println("Erro ao gerar relatorio de plantios: " + e.getMessage());
    }
    return lista;
}
}